# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 19:01:59 2019

@author: cash
"""

from Implique import *
from Variable import *

import ParseFormule


for i in range(5):
    for j in range(5):
        if i !=j: 
            print((i,j))


for i in range(5):
    for j in range(i,5):
        if i !=j: 
            print((i,j))

def test_it_interpretations():
    print("TEST SUR LES ITERATIONS SUR LES INTERPRETATIONS")
    i = 1
    for interp in Interpretation.iterateur_interpretations(["a", "b", "c"]) :
        print("interp", i, " = ", interp, sep = "")
        i = i + 1
        M=[]
        L=["ET(a,b)", "OU(a,b)"]
        for i in L:
            for j in L:
                if i!=j:
                    M.append("=>({0},{1})".format(1,2))




#Exercice 6: Base de connaissance 
    #(b): voir si une base de connaisance entraîne une formule 
    @staticmethod
    def Base_de_conaissance(D,phi) :
        #D : Base de connaissance
        #phi :Formule
        new_liste=[]
        for d in D :
            new_liste.append("=>({0},{1})".format(d,phi))
        
        for nd in new_liste:
            if type(nd) == str :
                nd = ParseFormule.exec(nd)
        n=0
        for interp in Interpretation.iterateur_interpretations(list(nd.get_variables())) :
            if interp.satisfait(nd)==False:
                n=n+1
        if n ==0 : 
           print("la Base de connaissance entraine la formule")
        else:
           print("la Base de connaissance n'entraine pas la formule")




                   

L=["TOP", "BOT", "a", "NON(a)", "ET(a, b)"]



L=["a","b","c","d"]

v="ET({0})".format(L[0])

v="{0}".format(L[0])
for i in range(1,len(L)):
    v="ET({0},{1})".format(L[i],v)
print(v)


L=["a","b","c","d","e","f"]
for i in L:
    k=L.index(i)
    for j in L[k::]:
        if i!=j:
            print(i,j)





#variavle 
def substitution_variable_par_formule(self,formule,v1) :
        VV=self.recolte_variables()
        VV=list(VV)
        for v2 in VV:
            if v2==self.v1:
               i=VV.index(v2)
               VV[i]=self.formule
               VV=set(VV)
        return VV



#####################
def calculateSquare(n):
    return n*n

numbers = (1, 2, 3, 4)

result = map(calculateSquare, numbers)


result
#<map at 0x174c845e240> ,problème on ne voit pas le résultat.Donc on fait
ss=set(result)


###########################################


L=["e","g","k","s","b","j","b","q","d","i","j","a"]
i=0
while i< len(L):
    if L[i]=="a":
        print("ouiiii on l'a trouvé :)!")
        break
    else:
        i=i+1
        if i==len(L):
            print("rien :( !")     
            
##########################################
S=["a","b","c"] 
A=[["b","a"],["a","c"],["c","b"]] 



def chemin(S,A):
    for L in A :
        for s in S:
            if [s,L[0]] in A:
                if ([s,L[1]] not in A):#and (L[1] != s):
                    A.append([s,L[1]])
                    A.append([L[1],s])
            if [L[1],s] in A:
                if ([L[0],s] not in A):#and (L[0] != s):
                    A.append([L[0],s])
                    A.append([s,L[0]])
    for i in A:
        print(i)

############################################################################################################
def val (x):
   y=x**2 if(x>0)  else 0
   return y  
       

def val (x):
   if(x>0) :
       y=x**2 
   else:
      y= 5
   return y  


def sign(i) :
    if (i>0):
        print("positif")
    elif(i<0):
        print("négatif")
    else:
        print("null")
        
        
for x in range(1,10,2.5):
    print(x**2)
    
 
    
def pgcd(a,b):
    if (b==0):
        return a 
    else:
        r=a%b
        return pgcd(b,r)  
    
    
    
def sq(x) : 
    return x*x
    
    
def somm(n,a,b):
    
    h=(b-a)/n
    s=0
    for i in range(n):
        s=s + sq(a + (i + 1/2)*h)
    return(h*s)    
    
######################################################
    
 
    
    def table(i): 
    #for i in range (1,10):
        for j in range (1,10): 
            m= "{0} x {1} = {2}".format(i,j,i*j)
            print(m)
          
l=[]   
for i in range(10): 
    if(i%3!=0):
      l.append(i**2)
print(l)
   


ll=[]
for i in range(3):
    for j in range(4):
        ll.append(10*i+j)
print(ll)
  

[[10*i+j for i in range(3)] for j in range(4)] 





l1 = ['Calvin', 'Wallace', 'Boule']
for i in range(len(l1)):
    print(i , l1[i])
    

for i , name in enumerate(l1):
    print(i, name)
    
    
    
l2 = ['Hobbes', 'Gromit', 'Bill']    
for n1, n2 in zip(l1, l2):
     print( n1, 'et', n2 ) 
     
     
 sorted(zip(l1, l2))     
     
 
 
 
 #################
 
 
for n in range(2, 10):
        for x in range(2, n):
            if n % x == 0:
                print( n, 'equals', x, '*', n/x)
                # break
        else:
            print( n, 'is a prime number')



for val in "string":
    
    if val == "i":
        break
    print(val)  
print("The end")
  


alpha = 'abcdefghijklmnopqrstuvwxyz'             
for val in alpha:
    print(val)
    if val== 't' :
         break
print('end')    

#########################################################################################################

from sklearn import datasets
iris = datasets.load_iris() 
digits= datasets.load_digits()
print(digits.data)        
print(iris.data)   

print(digits.target)  
print(iris.target)
digits.images[0]


from sklearn import svm
clf = svm.SVC(gamma=0.001, C=100.)
clf.fit(digits.data[:-1],digits.target[:-1])
clf.predict(digits.data[-1:])

from sklearn import svm
from sklearn import datasets 
clf = svm.SVC() 
 
X,y= datasets.load_iris(return_X_y=True)

clf.fit(X,y)

import pickle 
s=pickle.dumps(clf)
cl2= pickle.loads(s)
cl2.predict(X[0:1]) 
##########################################################################################################
 
import numpy as N 
import  matplotlib.pyplot as P

x=N.linspace(-N.pi,N.pi,100)
y=N.sin(x)             
fig, ax = P.subplots()
ax.plot(x,y)
ax.set_xlabel('ord')
ax.set_ylabel('abs')
ax.set_title('titree')
P.show()


import numpy as N import matplotlib.pyplot as P
x = N.linspace(-N.pi, N.pi, 100) 
y = N.sin(x)
fig, ax = P.subplots() # Création de la figure et de l'axe 
ax.plot(x, y) # Tracé de la courbe dans l'axe 
ax.set_xlabel("x [rad]") 
ax.set_ylabel("y") 
ax.set_title("y = sin(x)") 
P.show() # Affichage de la figure 

#####################################################################################################
import pandas as pd 
pd.options.display.max_rows=10
print(pd.__version__)


df=pd.read_table("heart.txt",sep="\t",header=0)

df = pd.read_table("C:/Users/YOULA Mohamed/Desktop/Algo/heart.txt",sep = '\t',header =0)
print(type(df))
print(df.shape)
print(df.size)
print(df.ndim)
print(df.head())

print(df.columns)
print(df.dtypes)
print(df.info())
print(df.describe(include='all'))
print(df['sexe'])



for i in df.columns :
    print(df[i].dtype)
    
    
    
import numpy as N

def operation2(x):
    return(N.mean(x))    
#######################################################################################################
import pandas as pd    
import numpy as N
pd.options.display.max_rows=10

df=pd.read_table("C:/Users/YOULA Mohamed/Desktop/Algo/heart.txt",sep='\t',header=0)
type(df)





for col in df.columns : 
    print(df[col].dtype)






































        
        

          
